from mysql_db import * 
now=int(time.time())
dats_to_baza=[]
pach='json'
tablic='json_transfer' 


for x in os.listdir(pach):
    if x.endswith('json'):
        #print(x)
        with open(pach + '/' + x, 'r') as f:
            content_json = f.read()
            #content_json=content_json.replace('"',"#")
            print(content_json)
        dats_to_baza.append((x,content_json,True,now))

input(f'Сonfirm adding lines : {len(dats_to_baza)} ')
add_opt(dats_to_baza,tablic)