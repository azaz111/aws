import os  , time
from argparse import ArgumentParser
from colorama import Fore , init
init(autoreset=True)
import configparser

from google_drive_respons import * 


def _list_users_token():
   sp=[path_users_token+'/'+x for x in os.listdir(path_users_token) if x.endswith('.json')]
   if not sp :
       print('UNABLE TO CONTINUE THERE ARE NO VALID USER ACCOUNTS')
       exit()
   return sp

def _list_serv_acc():
   sp=[path_serv_acc+'/'+x for x in os.listdir(path_serv_acc) if x.endswith('.json')]
   if not sp :
       print('UNABLE TO CONTINUE THERE ARE NO VALID SERVISE ACCOUNTS')
       exit()
   return sp

def transfer():
   unique=[]
   n=0
   while True:
       dirfiles = os.listdir(dirs)
       
       for qqq in  dirfiles:
          if qqq not in unique and os.stat(dirs+'/'+qqq).st_size > 108650979000:
              if qqq.endswith(".plot"):
                 
                n+=1
                d_tokens_list=[]

                while True:
                    if not d_tokens_list:
                       d_tokens_list=_list_users_token()
                    d_tokens=d_tokens_list.pop()
                    print(d_tokens)
                    if chek_ref(d_tokens):
                        break
                    else:
                        os.remove(d_tokens)
                    
                while True:
                    d_json_list=[]
                    if not d_json_list:
                       d_json_list=_list_serv_acc()
                    d_json=d_json_list.pop()
            
                    if check_json(d_json):
                        break
                    else:
                        os.remove(d_json)
                
                
                service=service_avtoriz_v3(d_tokens)
                team_drive=new_drive(service , str(n))
                print(Fore.GREEN+"DISK CREATED : " , team_drive)
                with open('id_drive.conf', 'a') as f:
                   f.write(team_drive+'\n')

                new_parents(service,team_drive,json=d_json)
                new_parents(service,team_drive,email=email)
                print(Fore.GREEN+" ... add perents servise acc + email: " , )
            
                with open(d_tokens, 'r') as f:
                   content=f.read()

                config = configparser.ConfigParser()
                config[f'drive_{n}'] = {'type': 'drive', 
                                             'token': d_tokens['json_content'],  
                                             'team_drive': team_drive}
            
                config[f'crypt_{n}'] = {
                                           'type': 'crypt',
                                           'remote': f'drive_{n}:',
                                           'password': crypto_paswd1,
                                           'password2': crypto_paswd2
                                            }
            
                with open(rclone_path, 'a') as f:
                   config.write(f)
                print(Fore.GREEN+"CREATED rclone.conf : " , rclone_path )

                time.sleep(5) 
                print('Start Transfer  ' + qqq[:5]+'....'+ qqq[-5:] + ' Nomber :' + str(n))
                com=f'screen -dmS trans{n} rclone move {dirs}/{qqq} crypt_{n}: --drive-stop-on-upload-limit --transfers 1 -P --drive-service-account-file {d_json} -v --log-file /root/rclone.log --drive-upload-cutoff=1000T'
                os.system(com)
                unique.append(qqq)
                if len(unique)>20: 
                    unique=unique[-20:]

       time.sleep(30)

if __name__ == '__main__':
    parse = ArgumentParser(description='Setting up a raft transfer.')
    parse.add_argument('--pach', default='/disk1', help='Directory with .plot on the server')
    parse.add_argument('--email', '-e' , help='Email manager , all disks will be linked')
    parse.add_argument('--path_users_token', '-puser' , default='tokens' , help='Directory of USER ACCOUNTS')
    parse.add_argument('--path_serv_acc', '-piam' , default='json', help='Directory of SERVISE ACCOUNTS')
    parse.add_argument('--rclone_config', '-rclone' , default='/root/.config/rclone/rclone.conf', help='Directory of SERVISE ACCOUNTS')

    parse.add_argument('--crypto_paswd1', '-cp1' , default='', help='Crypto paswd 1')
    parse.add_argument('--crypto_paswd2', '-cp2' , default='', help='Crypto paswd 2')

    args = parse.parse_args()

    crypto_paswd1=args.crypto_paswd1
    crypto_paswd2=args.crypto_paswd2

    path_users_token=args.path_users_token
    if not os.path.exists(path_users_token):
        os.mkdir(path_users_token)

    path_serv_acc=args.path_serv_acc
    if not os.path.exists(path_serv_acc):
        os.mkdir(path_serv_acc)

    email=args.email
    rclone_path=args.rclone_config
    dirs=args.pach


    transfer()