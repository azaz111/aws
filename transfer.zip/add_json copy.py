from mysql_db import * 

delet_yach('id > 0' )
now=int(time.time())
dats_to_baza=[]
pach='tokens'
for x in os.listdir(pach):
    if x.endswith('json'):
        #print(x)
        with open(pach + '/' + x, 'r') as f:
            content_json = f.read()
            #print(content_json)
        dats_to_baza.append((x,content_json,True,now))

input(f'Сonfirm adding lines : {len(dats_to_baza)} ')
add_opt(dats_to_baza)